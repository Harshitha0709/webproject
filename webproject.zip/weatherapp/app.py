from flask import Flask,render_template
import requests
import json
app = Flask(__name__)


@app.route('/')
def hello_world():
    uri = "https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b6907d289e10d714a6e88b30761fae22"
    try:
        uresponse = requests.get(uri)

    except requests.ConnectionError:
        return "Connection Error"
    jresponse = uresponse.text
    data = json.loads(jresponse)
    return render_template('index.html',data=data)


if __name__ == '__main__':
    app.run()
